-- MySQL dump 10.13  Distrib 5.7.15, for Linux (x86_64)
--
-- Host: 52.73.8.174    Database: osticket
-- ------------------------------------------------------
-- Server version	5.5.51

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ost_config`
--

DROP TABLE IF EXISTS `ost_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ost_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `namespace` varchar(64) NOT NULL,
  `key` varchar(64) NOT NULL,
  `value` text NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `namespace` (`namespace`,`key`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_config`
--

LOCK TABLES `ost_config` WRITE;
/*!40000 ALTER TABLE `ost_config` DISABLE KEYS */;
INSERT INTO `ost_config` VALUES (1,'core','admin_email','sowmya@exeterpremedia.com','2016-09-26 05:48:40'),(2,'core','helpdesk_url','http://52.73.8.174/osticket/','2016-09-20 09:46:58'),(3,'core','helpdesk_title','exeter','2016-09-20 09:46:58'),(4,'core','schema_signature','b26f29a6bb5dbb3510b057632182d138','2016-09-20 09:46:58'),(5,'dept.1','assign_members_only','','2016-09-20 09:46:57'),(6,'dept.2','assign_members_only','','2016-09-20 09:46:58'),(7,'dept.3','assign_members_only','','2016-09-20 09:46:58'),(8,'sla.1','transient','0','2016-09-20 09:46:58'),(9,'list.1','configuration','{\"handler\":\"TicketStatusList\"}','2016-09-20 09:46:58'),(10,'core','time_format','h:i A','2016-10-01 10:02:13'),(11,'core','date_format','m/d/Y','2016-09-20 09:46:58'),(12,'core','datetime_format','m/d/Y g:i a','2016-10-01 10:02:13'),(13,'core','daydatetime_format','D, M j Y g:ia','2016-10-01 10:02:13'),(14,'core','default_timezone_id','22','2016-09-21 12:05:30'),(15,'core','default_priority_id','1','2016-09-28 06:37:16'),(16,'core','enable_daylight_saving','1','2016-09-21 12:07:38'),(17,'core','reply_separator','-- reply above this line --','2016-09-20 09:46:58'),(18,'core','isonline','1','2016-09-20 09:46:58'),(19,'core','staff_ip_binding','0','2016-09-20 09:46:58'),(20,'core','staff_max_logins','4','2016-09-20 09:46:58'),(21,'core','staff_login_timeout','2','2016-09-20 09:46:58'),(22,'core','staff_session_timeout','30','2016-09-20 09:46:58'),(23,'core','passwd_reset_period','0','2016-09-20 09:46:58'),(24,'core','client_max_logins','4','2016-09-20 09:46:58'),(25,'core','client_login_timeout','2','2016-09-20 09:46:58'),(26,'core','client_session_timeout','30','2016-09-20 09:46:58'),(27,'core','max_page_size','25','2016-09-20 09:46:58'),(28,'core','max_open_tickets','0','2016-09-20 09:46:58'),(29,'core','autolock_minutes','0','2016-10-01 12:08:57'),(30,'core','default_smtp_id','0','2016-09-20 09:46:58'),(31,'core','use_email_priority','1','2016-09-21 04:28:15'),(32,'core','enable_kb','1','2016-09-21 04:18:10'),(33,'core','enable_premade','1','2016-09-20 09:46:58'),(34,'core','enable_captcha','0','2016-09-20 09:46:58'),(35,'core','enable_auto_cron','1','2016-09-21 04:53:11'),(36,'core','enable_mail_polling','1','2016-09-21 04:25:03'),(37,'core','send_sys_errors','0','2016-09-21 04:29:03'),(38,'core','send_sql_errors','1','2016-09-20 09:46:58'),(39,'core','send_login_errors','1','2016-09-20 09:46:58'),(40,'core','save_email_headers','1','2016-09-20 09:46:58'),(41,'core','strip_quoted_reply','1','2016-09-20 09:46:58'),(42,'core','ticket_autoresponder','0','2016-09-28 10:36:33'),(43,'core','message_autoresponder','0','2016-09-28 10:36:33'),(44,'core','ticket_notice_active','0','2016-09-28 10:36:33'),(45,'core','ticket_alert_active','0','2016-09-26 09:09:48'),(46,'core','ticket_alert_admin','1','2016-09-20 09:46:58'),(47,'core','ticket_alert_dept_manager','0','2016-09-26 09:09:48'),(48,'core','ticket_alert_dept_members','0','2016-09-20 09:46:58'),(49,'core','message_alert_active','0','2016-09-26 09:09:48'),(50,'core','message_alert_laststaff','1','2016-09-20 09:46:58'),(51,'core','message_alert_assigned','1','2016-09-20 09:46:58'),(52,'core','message_alert_dept_manager','0','2016-09-20 09:46:58'),(53,'core','note_alert_active','0','2016-09-26 09:09:48'),(54,'core','note_alert_laststaff','1','2016-09-20 09:46:58'),(55,'core','note_alert_assigned','1','2016-09-20 09:46:58'),(56,'core','note_alert_dept_manager','0','2016-09-20 09:46:58'),(57,'core','transfer_alert_active','0','2016-09-26 09:09:48'),(58,'core','transfer_alert_assigned','1','2016-09-26 08:38:13'),(59,'core','transfer_alert_dept_manager','0','2016-09-26 09:09:48'),(60,'core','transfer_alert_dept_members','0','2016-09-20 09:46:58'),(61,'core','overdue_alert_active','0','2016-09-26 09:09:48'),(62,'core','overdue_alert_assigned','1','2016-09-20 09:46:58'),(63,'core','overdue_alert_dept_manager','0','2016-09-26 09:09:48'),(64,'core','overdue_alert_dept_members','0','2016-09-20 09:46:58'),(65,'core','assigned_alert_active','0','2016-09-26 09:09:48'),(66,'core','assigned_alert_staff','1','2016-09-20 09:46:58'),(67,'core','assigned_alert_team_lead','0','2016-09-20 09:46:58'),(68,'core','assigned_alert_team_members','0','2016-09-20 09:46:58'),(69,'core','auto_claim_tickets','1','2016-09-28 12:33:59'),(70,'core','show_related_tickets','0','2016-09-21 04:15:55'),(71,'core','show_assigned_tickets','1','2016-09-26 05:45:33'),(72,'core','show_answered_tickets','1','2016-09-26 05:45:33'),(73,'core','hide_staff_name','0','2016-09-20 09:46:58'),(74,'core','overlimit_notice_active','0','2016-09-28 10:36:33'),(75,'core','email_attachments','1','2016-09-20 09:46:58'),(76,'core','number_format','######','2016-09-26 07:18:04'),(77,'core','sequence_id','1','2016-09-21 04:15:55'),(78,'core','log_level','2','2016-10-08 11:04:16'),(79,'core','log_graceperiod','12','2016-09-20 09:46:58'),(80,'core','client_registration','public','2016-09-20 09:46:58'),(81,'core','max_file_size','536870912','2016-09-20 09:46:58'),(82,'core','landing_page_id','1','2016-09-20 09:46:58'),(83,'core','thank-you_page_id','2','2016-09-20 09:46:58'),(84,'core','offline_page_id','3','2016-09-20 09:46:58'),(85,'core','system_language','en_US','2016-09-20 09:46:58'),(86,'mysqlsearch','reindex','0','2016-09-20 09:50:07'),(87,'core','default_email_id','6','2016-09-26 07:33:33'),(88,'core','alert_email_id','0','2016-09-21 04:17:09'),(89,'core','default_dept_id','5','2016-09-28 04:44:53'),(90,'core','default_sla_id','1','2016-09-20 09:46:58'),(91,'core','default_template_id','1','2016-09-20 09:46:58'),(93,'core','name_format','full','2016-09-21 04:09:52'),(94,'core','client_logo_id','3','2016-09-21 04:14:45'),(95,'core','staff_logo_id','3','2016-09-21 04:14:45'),(96,'core','default_help_topic','0','2016-09-21 04:15:55'),(97,'core','default_ticket_status_id','1','2016-09-21 04:15:55'),(98,'core','enable_html_thread','1','2016-09-21 04:15:55'),(99,'core','allow_client_updates','1','2016-09-21 04:24:30'),(100,'core','verify_email_addrs','1','2016-09-21 04:16:25'),(101,'core','accept_unregistered_email','1','2016-09-21 04:16:25'),(102,'core','add_email_collabs','1','2016-09-21 04:16:25'),(103,'core','restrict_kb','1','2016-09-21 04:18:10'),(104,'core','message_autoresponder_collabs','0','2016-09-28 10:36:33'),(105,'core','ticket_alert_acct_manager','0','2016-09-21 04:29:03'),(106,'core','message_alert_acct_manager','0','2016-09-21 04:29:03'),(109,'staff.1','lang','','2016-09-21 11:28:44'),(110,'sla.2','transient','1','2016-09-26 06:56:22'),(111,'pwreset','M9o3a3uNqK=xjEFV16uVNgwtJ14HAGA0Q6zq8m=cYxjrRe7N','26','2016-09-23 05:31:54'),(112,'pwreset','C8XIinSEofTApX1Uv8LPZt5cC8GT10iqHbNpUkj9Gr2aw4wa','21','2016-09-23 06:21:43'),(113,'pwreset','NrBCfCB07hhYT0f4uKgiWPMpXM6dtIFu1G011Pf7cKpotoqy','28','2016-09-23 08:34:13'),(115,'dept.4','assign_members_only','','2016-09-23 08:50:05'),(116,'staff.5','lang','','2016-09-23 08:57:25'),(117,'dept.5','assign_members_only','','2016-09-26 06:29:26'),(118,'pwreset','NCXhc970PoFnKPZFedUlQ6jLsAqIdH50D=LkV3jcXU736Z3v','26','2016-09-26 07:36:00'),(120,'staff.2','lang','','2016-09-26 07:59:50'),(124,'staff.7','lang','','2016-09-29 11:29:44'),(126,'staff.8','lang','','2016-10-03 08:56:29'),(127,'sla.3','transient','0','2016-10-05 12:51:52'),(129,'pwreset','kkW7kymUloTanrHZQTYoCpRZnBddhJgbR5lZ80aH2vTpGt09','10','2016-10-06 12:45:57');
/*!40000 ALTER TABLE `ost_config` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-10-12 14:48:36
