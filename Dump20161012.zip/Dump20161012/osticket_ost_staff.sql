-- MySQL dump 10.13  Distrib 5.7.15, for Linux (x86_64)
--
-- Host: 52.73.8.174    Database: osticket
-- ------------------------------------------------------
-- Server version	5.5.51

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ost_staff`
--

DROP TABLE IF EXISTS `ost_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ost_staff` (
  `staff_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dept_id` int(10) unsigned NOT NULL DEFAULT '0',
  `timezone_id` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(32) NOT NULL DEFAULT '',
  `firstname` varchar(32) DEFAULT NULL,
  `lastname` varchar(32) DEFAULT NULL,
  `passwd` varchar(128) DEFAULT NULL,
  `backend` varchar(32) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `phone` varchar(24) NOT NULL DEFAULT '',
  `phone_ext` varchar(6) DEFAULT NULL,
  `mobile` varchar(24) NOT NULL DEFAULT '',
  `signature` text NOT NULL,
  `notes` text,
  `isactive` tinyint(1) NOT NULL DEFAULT '1',
  `isadmin` tinyint(1) NOT NULL DEFAULT '0',
  `isvisible` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `onvacation` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `assigned_only` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `show_assigned_tickets` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `daylight_saving` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `change_passwd` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `max_page_size` int(11) unsigned NOT NULL DEFAULT '0',
  `auto_refresh_rate` int(10) unsigned NOT NULL DEFAULT '0',
  `default_signature_type` enum('none','mine','dept') NOT NULL DEFAULT 'none',
  `default_paper_size` enum('Letter','Legal','Ledger','A4','A3') NOT NULL DEFAULT 'Letter',
  `created` datetime NOT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `passwdreset` datetime DEFAULT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`staff_id`),
  UNIQUE KEY `username` (`username`),
  KEY `dept_id` (`dept_id`),
  KEY `issuperuser` (`isadmin`),
  KEY `group_id` (`group_id`,`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_staff`
--

LOCK TABLES `ost_staff` WRITE;
/*!40000 ALTER TABLE `ost_staff` DISABLE KEYS */;
INSERT INTO `ost_staff` VALUES (1,4,1,22,'shariff','Shariff','Shariff','$2a$08$L93E0HHBB0FyOKcFULB3wOuotaiyLmZH4GOX.N4QUKDh7/M3/ewAu','','mohammedshariff@exeterpm.com','','','','','',1,1,1,0,0,0,1,0,25,1,'none','Letter','2016-09-20 15:16:58','2016-10-04 09:49:09',NULL,'2016-10-01 17:38:18'),(2,4,1,22,'Sowmya','Sowmya','Mahadevan','$2a$08$6KsX.cl.y.t9wBKQXZZWBO6A7pzO0YaAGj/zxUqWVWKk3jbbPsZPu','','sowmya@exeterpremedia.com','','','','','',1,1,1,0,0,1,1,0,25,0,'none','Letter','2016-09-20 15:30:28','2016-10-12 14:10:15','2016-09-26 13:29:50','2016-10-01 17:39:31'),(3,4,5,22,'Lakshmi','Lakshmi','Exeter','$2a$08$sSwrXH7jkI6FNfRd2b9.7.pwzS2DhAHtWfJAU64wJsb4LlLf3CaFm','local','lakshmi@exeterpm.com','','','','','',1,0,1,0,0,0,1,0,0,0,'none','Letter','2016-09-21 16:39:36','2016-10-12 12:42:20',NULL,'2016-10-01 17:39:12'),(4,4,5,22,'Renganath','Renganath','Exeter','$2a$08$Q.4GnuW9pKjDGYXUKR5kI.teJgZyqhEc27fxhYsJHKUfDzrCag7FS','','renganath@exeterpm.com','','','','','',1,0,1,0,0,0,1,0,0,0,'none','Letter','2016-09-21 16:40:23','2016-09-22 11:51:56',NULL,'2016-10-01 17:39:20'),(5,4,4,15,'m.harrison','Melissa','Harrison','$2a$08$jDZI8zbAHIs.3Hj7BLEmqu7tunvWrpZoh8MWAY7O9ItKcLMhGGr26','','m.harrison@elifesciences.org','','','','','',1,0,0,0,0,0,1,0,25,0,'none','Letter','2016-09-23 14:18:33','2016-10-11 14:13:23','2016-09-23 14:27:25','2016-10-11 13:30:38'),(6,4,5,22,'sarumathi','Sarumathi','M','$2a$08$3Kx2hRGia2f4lkq.4ZHUPu4MX.7/u1Ts.x43dz9dVOAXl9UpY.krm','','sarumathi@exeterpm.com','','','','','',1,0,1,0,0,0,1,0,0,0,'none','Letter','2016-09-27 15:46:55','2016-10-12 11:52:32',NULL,'2016-09-28 10:09:57'),(7,4,1,22,'thinakaran','Thinakaran','D','$2a$08$3SR0lQ5Hjn/4USIs1bMQ..0VvUtn64jvh6fBx2tsjjNZfaOzh7PKm','','thinakaran@exeterpremedia.com','','','','','',1,0,1,0,0,0,1,0,25,0,'none','Letter','2016-09-29 16:46:48','2016-10-12 13:14:11','2016-10-12 09:43:26','2016-10-12 09:43:26'),(8,4,5,22,'saravanan','Saravanan','S','$2a$08$bG1qDRK7IHlj3/FZPl4lbux9fthlP1fmfV1LNISxaACQ7wBfvtnni','','support@exeterpremedia.com','','','','','',1,1,1,0,0,0,1,0,25,0,'none','Letter','2016-10-03 12:43:26','2016-10-12 14:06:24',NULL,'2016-10-05 11:21:58'),(9,4,5,22,'Kavitha','Kavitha','Exeter','$2a$08$RwBRW43GCen8Fx9k4bkjNet2Q23UfgL.B3rYt8ygI7Os6.y4uFiW.','','kavithat@exeterpm.com','','','','','',1,1,1,0,0,0,1,0,0,0,'none','Letter','2016-10-06 10:22:36','2016-10-12 14:27:32',NULL,'2016-10-06 10:53:38'),(10,4,5,22,'Vinoth','Vinoth','Exeter','$2a$08$c24yVPYfbOh9jAmK3JXxXe5zJqY0WBNOIy2Drh06L.ulylxSNmG0y','','vinothd@exeterpm.com','','','','','',1,0,1,0,0,0,1,1,0,0,'none','Letter','2016-10-06 18:15:57',NULL,NULL,'2016-10-06 18:17:06'),(11,4,5,22,'Navin','Navin','Exeter','$2a$08$FzSiYfqmONCrGBK6ZWywjOWxgCzVWrPKsc//iMf3DBgvgqVPpYh1C','local','navin@exeterpm.com','','','','','',1,0,1,0,0,0,1,1,0,0,'none','Letter','2016-10-12 14:08:04',NULL,NULL,'2016-10-12 14:08:04');
/*!40000 ALTER TABLE `ost_staff` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-10-12 14:49:06
