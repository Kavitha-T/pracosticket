-- MySQL dump 10.13  Distrib 5.7.15, for Linux (x86_64)
--
-- Host: 52.73.8.174    Database: osticket
-- ------------------------------------------------------
-- Server version	5.5.51

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ost_user_email`
--

DROP TABLE IF EXISTS `ost_user_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ost_user_email` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `address` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `address` (`address`),
  KEY `user_email_lookup` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=170 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_user_email`
--

LOCK TABLES `ost_user_email` WRITE;
/*!40000 ALTER TABLE `ost_user_email` DISABLE KEYS */;
INSERT INTO `ost_user_email` VALUES (1,1,'support@osticket.com'),(2,2,'mohammedshariffkm@gmail.com'),(3,3,'wfm@exeterpremedia.com'),(4,4,'kriya@elifesciences.org'),(5,5,'support@exeterpremedia.com'),(6,6,'no-reply@accounts.google.com'),(7,7,'mail@flipkartletters.com'),(8,8,'sasikala.exeter@gmail.com'),(9,9,'production@elifesciences.org'),(10,10,'anuraja.exeter@gmail.com'),(11,11,'noreply@160by2.us'),(12,12,'store-news@amazon.in'),(13,13,'information@hdfcbank.net'),(14,14,'microbiology@exeterpremedia.com'),(15,15,'windowsinsiderprogram@e-mail.microsoft.com'),(16,16,'venkatesh@exeterpremedia.com'),(17,17,'elifesupport@exeterpremedia.com'),(18,18,'sowmya@exeterpremedia.com'),(19,19,'ayyappan.exeter@gmail.com'),(20,20,'alert@shine.com'),(21,21,'ramesh@exeterpremedia.com'),(22,22,'marketing@sw.solarwinds.com'),(23,23,'no-reply@bounces.careesma.in'),(24,24,'community-support@manageengine.com'),(25,25,'newsletter@mailers.e-redbus.in'),(26,26,'sowmya.venka@gmail.com'),(27,27,'newsletter@autstory.com'),(28,28,'m.harrison@elifesciences.org'),(29,29,'information@mailer.hdfcbank.net'),(30,30,'ravi@exeterpremedia.com'),(31,31,'noreply@160by2invite.com'),(32,32,'noreply@ziprecruiter.com'),(33,33,'elife-support@glencoesoftware.com'),(34,34,'iwitten@princeton.edu'),(35,35,'hessam.akhlaghpour@gmail.com'),(36,36,'schekman@berkeley.edu'),(37,37,'burkhala@wustl.edu'),(38,38,'maduravalli.exeter@gmail.com'),(39,39,'jayalakshmi@exeterpremedia.com'),(40,40,'editorial@elifesciences.org'),(41,41,'baris.tursun@mdc-berlin.de'),(42,42,'rafal.ciosk@fmi.ch'),(43,43,'reddien@wi.mit.edu'),(44,44,'iwang2@stanford.edu'),(45,45,'e.packer@elifesciences.org'),(46,46,'features@elifesciences.org'),(47,47,'isabel.baeurle@uni-potsdam.de'),(48,48,'mshurtleff@berkeley.edu'),(49,49,'mailer-daemon@eigbox.net'),(50,50,'abdel.elmanira@ki.se'),(51,51,'hongbo.zhu@tuebingen.mpg.de'),(52,52,'andrei.lupas@tuebingen.mpg.de'),(53,53,'production@exeterpremedia.com'),(54,54,'jpearson@unsw.edu.au'),(55,55,'nancy.papalopulu@manchester.ac.uk'),(56,56,'osheae@hhmi.org'),(57,57,'shapiro@convex.hhmi.columbia.edu'),(58,58,'kbarton@carnegiescience.edu'),(59,59,'lakshmi.exeter@gmail.com'),(60,60,'pari@exeterpremedia.com'),(61,61,'kumar@exeterpremedia.com'),(62,62,'bmjjournals@exeterpremedia.com'),(63,63,'s.king@elifesciences.org'),(64,64,'kamesh.exeterpm@gmail.com'),(65,65,'annette.macleod@glasgow.ac.uk'),(66,66,'perezcamps.m@gmail.com'),(67,67,'bruno@reversade.com'),(68,68,'paul.riley@dpag.ox.ac.uk'),(69,69,'richard.tyser@dpag.ox.ac.uk'),(70,70,'antonio.miranda@trinity.ox.ac.uk'),(71,71,'shankar.srinivas@dpag.ox.ac.uk'),(72,72,'apthangaraj@gmail.com'),(73,73,'yihong.wan@utsouthwestern.edu'),(74,74,'richard.lifton@yale.edu'),(75,75,'rhrgalb@illinois.edu'),(76,76,'marc.hammarlund@yale.edu'),(77,77,'tal.golan@alice.nc.huji.ac.il'),(78,78,'rafi.malach@gmail.com'),(79,79,'egc2119@columbia.edu'),(80,80,'jlm2@columbia.edu'),(81,81,'fra.garbarini@gmail.com'),(82,82,'notifications@basecamp.com'),(83,83,'michalis.averof@ens-lyon.fr'),(84,84,'falwes@mail.com'),(85,85,'camille.enjolras@ens-lyon.fr'),(86,86,'vijayakumar.exeter@gmail.com'),(87,87,'no-reply@dropbox.com'),(88,88,'vendors@exeterpremedia.com'),(89,89,'herreras@cajal.csic.es'),(90,90,'nicholas.ktistakis@babraham.ac.uk'),(91,91,'chisholm@ucsd.edu'),(92,92,'david.sherwood@duke.edu'),(93,93,'hirokawa@m.u-tokyo.ac.jp'),(94,94,'mishina@umich.edu'),(95,95,'p.rodgers@elifesciences.org'),(96,96,'pgarrity@brandeis.edu'),(97,97,'andrew.timberlake@yale.edu'),(98,98,'laurence.hunt@ucl.ac.uk'),(99,99,'s.kennerley@ucl.ac.uk'),(100,100,'sean.cavanagh.12@ucl.ac.uk'),(101,101,'nick.phillips@manchester.ac.uk'),(102,102,'nhao@ucsd.edu'),(103,103,'lepper@ciwemb.edu'),(104,104,'tim@cos.io'),(105,105,'njm25@cam.ac.uk'),(106,106,'pjl30@cam.ac.uk'),(107,107,'ed.greenwood@gmail.com'),(108,108,'xiaojun.ren@ucdenver.edu'),(109,109,'ejdg2@cam.ac.uk'),(110,110,'sergei.sokol@mssm.edu'),(111,111,'lorena.deuker@rub.de'),(112,112,'ajohnson@cgl.ucsf.edu'),(113,113,'chirajdalal.ucsf@gmail.com'),(114,114,'xiaoping.zhong@duke.edu'),(115,115,'dji@bcm.edu'),(116,116,'xiaoyi8607@gmail.com'),(117,117,'cthittinger@wisc.edu'),(118,118,'karsten.weis@bc.biol.ethz.ch'),(119,119,'bjmeyer@berkeley.edu'),(120,120,'feig@msu.edu'),(121,121,'lindorff@bio.ku.dk'),(122,122,'cyril.hanus@brain.mpg.de'),(123,123,'erin.schuman@brain.mpg.de'),(124,124,'julian.langer@brain.mpg.de'),(125,125,'yuanyi-feng@northwestern.edu'),(126,126,'or38@columbia.edu'),(127,127,'mkwong2@wisc.edu'),(128,128,'john.bowman@monash.edu'),(129,129,'peter.zammit@kcl.ac.uk'),(130,130,'joshua.brickman@sund.ku.dk'),(131,131,'n.duffield@elifesciences.org'),(132,132,'ysasaki@genetics.wustl.edu'),(133,133,'p.a.lynch@exeter.ac.uk'),(134,134,'hamish.king@gtc.ox.ac.uk'),(135,135,'rob.klose@bioch.ox.ac.uk'),(136,136,'rose.nathan@gmail.com'),(137,137,'thinakaran@exeterpremedia.com'),(138,138,'gebelo@utu.fi'),(139,139,'matti.turtola@utu.fi'),(140,140,'francesca.garbarini@unito.it'),(141,141,'ashalev@uabmc.edu'),(142,142,'shalev@uab.edu'),(143,143,'john.huguenard@stanford.edu'),(144,144,'fg292@cam.ac.uk'),(145,145,'naiyan@mit.edu'),(146,146,'fengg@mit.edu'),(147,147,'weiping_han@sbic.a-star.edu.sg'),(148,148,'sumesh@exeterpremedia.com'),(149,149,'vivekanandan@exeterpremedia.com'),(150,150,'ian.ramsey@vcuhealth.org'),(151,151,'satu.palva@helsinki.fi'),(152,152,'guy1eyal@gmail.com'),(153,153,'ingolf.bach@umassmed.edu'),(154,154,'mhorlbeck@gmail.com'),(155,155,'jonathan.weissman@ucsf.edu'),(156,156,'fortune502@gmail.com'),(157,157,'vjlynch@uchicago.edu'),(158,158,'jekimble@wisc.edu'),(159,159,'christopher-ahern@uiowa.edu'),(160,160,'jcooper@fhcrc.org'),(161,161,'neil.blackledge@bioch.ox.ac.uk'),(162,162,'benny.shilo@weizmann.ac.il'),(163,163,'jeff.molkentin@cchmc.org'),(164,164,'dmgarcia@stanford.edu'),(165,165,'jarosz@stanford.edu'),(166,166,'mather.simon@gmail.com'),(167,167,'fabian.grabenhorst@googlemail.com'),(168,168,'yooa@wustl.edu'),(169,169,'wierzbic@umich.edu');
/*!40000 ALTER TABLE `ost_user_email` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-10-12 14:47:44
