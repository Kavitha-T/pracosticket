-- MySQL dump 10.13  Distrib 5.7.15, for Linux (x86_64)
--
-- Host: 52.73.8.174    Database: osticket
-- ------------------------------------------------------
-- Server version	5.5.51

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ost_filter_rule`
--

DROP TABLE IF EXISTS `ost_filter_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ost_filter_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `filter_id` int(10) unsigned NOT NULL DEFAULT '0',
  `what` varchar(32) NOT NULL,
  `how` enum('equal','not_equal','contains','dn_contain','starts','ends','match','not_match') NOT NULL,
  `val` varchar(255) NOT NULL,
  `isactive` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `notes` tinytext NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filter` (`filter_id`,`what`,`how`,`val`),
  KEY `filter_id` (`filter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=328 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ost_filter_rule`
--

LOCK TABLES `ost_filter_rule` WRITE;
/*!40000 ALTER TABLE `ost_filter_rule` DISABLE KEYS */;
INSERT INTO `ost_filter_rule` VALUES (1,1,'email','equal','test@example.com',1,'','2016-09-20 15:16:58','2016-09-20 15:16:58'),(108,33,'field.1','equal','mohammedshariffkm@gmail.com',1,'','2016-09-28 17:39:05','2016-09-28 17:39:05'),(109,33,'field.20','starts','/Delivery',1,'','2016-09-28 17:39:05','2016-09-28 17:39:05'),(118,34,'field.1','equal','mohammedshariffkm@gmail.com',1,'','2016-09-28 18:16:27','2016-09-28 18:16:27'),(119,34,'field.20','contains','/High',1,'','2016-09-28 18:16:27','2016-09-28 18:16:27'),(163,7,'field.1','equal','wfm@exeterpremedia.com',1,'','2016-09-29 18:11:29','2016-09-29 18:11:29'),(164,7,'field.20','contains','Package Creation and Upload Status (Pre-editing)',1,'','2016-09-29 18:11:29','2016-09-29 18:11:29'),(165,7,'field.20','contains','Success',1,'','2016-09-29 18:11:29','2016-09-29 18:11:29'),(214,27,'field.1','contains','elifesciences.org',1,'','2016-10-05 17:57:21','2016-10-05 17:57:21'),(215,27,'field.20','starts','Bug/',1,'','2016-10-05 17:57:21','2016-10-05 17:57:21'),(216,25,'field.1','contains','elifesciences.org',1,'','2016-10-05 17:59:24','2016-10-05 17:59:24'),(217,25,'field.20','starts','Delivery/',1,'','2016-10-05 17:59:24','2016-10-05 17:59:24'),(226,28,'field.1','contains','elifesciences.org',1,'','2016-10-05 18:12:28','2016-10-05 18:12:28'),(227,28,'field.20','starts','Author/',1,'','2016-10-05 18:12:28','2016-10-05 18:12:28'),(230,8,'field.1','equal','elife-support@glencoesoftware.com',1,'','2016-10-05 18:14:05','2016-10-05 18:14:05'),(231,8,'field.20','contains','1 Manuscript Video Processing',1,'','2016-10-05 18:14:05','2016-10-05 18:14:05'),(235,11,'field.1','equal','wfm@exeterpremedia.com',1,'','2016-10-05 18:14:28','2016-10-05 18:14:28'),(236,11,'field.20','contains','Package Creation and Upload Status (Author Review)',1,'','2016-10-05 18:14:28','2016-10-05 18:14:28'),(237,11,'field.20','contains','Success',1,'','2016-10-05 18:14:28','2016-10-05 18:14:28'),(238,4,'field.1','equal','wfm@exeterpremedia.com',1,'','2016-10-05 18:14:40','2016-10-05 18:14:40'),(239,4,'field.20','contains','Auto Content Loading Success Report: elife',1,'','2016-10-05 18:14:40','2016-10-05 18:14:40'),(240,21,'field.1','equal','production@exeterpremedia.com',1,'','2016-10-05 18:17:27','2016-10-05 18:17:27'),(241,21,'field.20','contains','ELIFE success report',1,'','2016-10-05 18:17:27','2016-10-05 18:17:27'),(242,6,'field.1','equal','production@exeterpremedia.com',1,'','2016-10-05 18:17:53','2016-10-05 18:17:53'),(243,6,'field.20','contains','ELIFE success report for',1,'','2016-10-05 18:17:53','2016-10-05 18:17:53'),(250,9,'field.1','equal','wfm@exeterpremedia.com',1,'','2016-10-05 18:25:09','2016-10-05 18:25:09'),(251,9,'field.20','equal','^.?Failure\\s:\\s*[0-9]+\\s\\([0-9]+\\)\\s*\\-\\s*Package Creation and Upload Status \\(Pre\\-editing\\)',1,'','2016-10-05 18:25:09','2016-10-05 18:25:09'),(253,10,'field.1','equal','editorial@elifesciences.org',1,'','2016-10-05 18:26:37','2016-10-05 18:26:37'),(260,17,'field.1','equal','wfm@exeterpremedia.com',1,'','2016-10-05 18:30:18','2016-10-05 18:30:18'),(261,17,'field.20','contains','Package Creation and Upload Status (Final Deliverables)',1,'','2016-10-05 18:30:18','2016-10-05 18:30:18'),(262,17,'field.20','contains','Success',1,'','2016-10-05 18:30:18','2016-10-05 18:30:18'),(266,18,'field.20','equal','wfm@exeterpremedia.com',1,'','2016-10-05 18:30:44','2016-10-05 18:30:44'),(267,18,'field.20','contains','Failure',1,'','2016-10-05 18:30:44','2016-10-05 18:30:44'),(268,18,'field.20','contains','Package Creation and Upload Status (Final Deliverables)',1,'','2016-10-05 18:30:44','2016-10-05 18:30:44'),(269,31,'field.1','contains','elifesciences.org',1,'','2016-10-05 18:32:11','2016-10-05 18:32:11'),(270,31,'field.20','contains','/High',1,'','2016-10-05 18:32:11','2016-10-05 18:32:11'),(271,26,'field.1','contains','elifesciences.org',1,'','2016-10-05 18:33:06','2016-10-05 18:33:06'),(272,26,'field.20','contains','/low',1,'','2016-10-05 18:33:06','2016-10-05 18:33:06'),(274,2,'field.1','equal','m.harrison@elifesciences.org',1,'','2016-10-05 18:36:05','2016-10-05 18:36:05'),(275,5,'field.1','equal','mailer-daemon@googlemail.com',1,'','2016-10-05 18:38:11','2016-10-05 18:38:11'),(276,5,'field.20','contains','Mail delivery failed:',1,'','2016-10-05 18:38:11','2016-10-05 18:38:11'),(279,30,'field.1','contains','elifesciences.org',1,'','2016-10-05 18:39:07','2016-10-05 18:39:07'),(280,30,'field.20','contains','/Normal',1,'','2016-10-05 18:39:07','2016-10-05 18:39:07'),(281,29,'field.1','contains','elifesciences.org',1,'','2016-10-05 18:40:12','2016-10-05 18:40:12'),(282,29,'field.20','starts','Enhancement/',1,'','2016-10-05 18:40:12','2016-10-05 18:40:12'),(283,19,'field.1','equal','production@elifesciences.org',1,'','2016-10-05 18:40:40','2016-10-05 18:40:40'),(284,19,'field.20','contains','DepositCrossref Success!',1,'','2016-10-05 18:40:40','2016-10-05 18:40:40'),(289,22,'field.1','equal','wfm@exeterpremedia.com',1,'','2016-10-05 18:44:14','2016-10-05 18:44:14'),(290,22,'field.20','equal','Package Creation and Upload Status',1,'','2016-10-05 18:44:14','2016-10-05 18:44:14'),(293,24,'field.1','equal','elifesupport@exeterpremedia.com',1,'','2016-10-05 18:45:33','2016-10-05 18:45:33'),(294,24,'field.20','contains','PAW update Failure',1,'','2016-10-05 18:45:33','2016-10-05 18:45:33'),(298,14,'field.1','equal','wfm@exeterpremedia.com',1,'','2016-10-05 18:49:19','2016-10-05 18:49:19'),(299,14,'field.20','contains','Package Creation and Upload Status (Pre-editing)',1,'','2016-10-05 18:49:19','2016-10-05 18:49:19'),(300,14,'field.20','contains','Success',1,'','2016-10-05 18:49:19','2016-10-05 18:49:19'),(303,3,'field.1','equal','kriya@elifesciences.org',1,'','2016-10-05 18:51:19','2016-10-05 18:51:19'),(304,3,'field.20','starts','Proof for eLife.',1,'','2016-10-05 18:51:19','2016-10-05 18:51:19'),(305,16,'field.1','equal','wfm@exeterpremedia.com',1,'','2016-10-05 18:52:39','2016-10-05 18:52:39'),(306,16,'field.20','contains','Failure',1,'','2016-10-05 18:52:39','2016-10-05 18:52:39'),(307,16,'field.20','contains','Package Creation and Upload Status (Publisher Check)',1,'','2016-10-05 18:52:39','2016-10-05 18:52:39'),(308,15,'field.1','equal','wfm@exeterpremedia.com',1,'','2016-10-05 18:53:58','2016-10-05 18:53:58'),(309,15,'field.20','contains','Package Creation and Upload Status (Publisher Check)',1,'','2016-10-05 18:53:58','2016-10-05 18:53:58'),(310,15,'field.20','contains','Success',1,'','2016-10-05 18:53:58','2016-10-05 18:53:58'),(313,20,'field.1','equal','production@elifesciences.org',1,'','2016-10-05 18:55:25','2016-10-05 18:55:25'),(314,20,'field.20','contains','PubmedArticleDeposit Success!',1,'','2016-10-05 18:55:25','2016-10-05 18:55:25'),(315,12,'field.1','equal','wfm@exeterpremedia.com',1,'','2016-10-05 18:56:51','2016-10-05 18:56:51'),(316,12,'field.20','contains','Failure',1,'','2016-10-05 18:56:51','2016-10-05 18:56:51'),(317,12,'field.20','contains','Package Creation and Upload Status (Author Review)',1,'','2016-10-05 18:56:51','2016-10-05 18:56:51'),(318,23,'field.1','equal','notifications@basecamp.com',1,'','2016-10-05 18:57:10','2016-10-05 18:57:10'),(319,23,'field.20','contains','(Production vendor transition)',1,'','2016-10-05 18:57:10','2016-10-05 18:57:10'),(320,13,'field.1','equal','wfm@exeterpremedia.com',1,'','2016-10-05 18:58:12','2016-10-05 18:58:12'),(321,13,'field.20','contains','Failure',1,'','2016-10-05 18:58:12','2016-10-05 18:58:12'),(322,13,'field.20','contains','Package Creation and Upload Status (Pre-editing)',1,'','2016-10-05 18:58:12','2016-10-05 18:58:12'),(323,35,'field.1','equal','production@exeterpremedia.com',1,'','2016-10-06 18:22:55','2016-10-06 18:22:55'),(324,35,'field.20','contains','ELIFE success report',1,'','2016-10-06 18:22:55','2016-10-06 18:22:55'),(325,32,'field.1','contains','elifesciences.org',1,'','2016-10-08 13:23:58','2016-10-08 13:23:58'),(326,32,'field.20','contains','/Emergency',1,'','2016-10-08 13:23:58','2016-10-08 13:23:58'),(327,32,'field.20','contains','emergency',1,'','2016-10-08 13:23:58','2016-10-08 13:23:58');
/*!40000 ALTER TABLE `ost_filter_rule` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-10-12 14:48:55
